from django.apps import AppConfig


class TripAppConfig(AppConfig):
    name = 'trip_app'
